﻿namespace Lab_Das_6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnShowFor = new System.Windows.Forms.Button();
            this.btnCreateList = new System.Windows.Forms.Button();
            this.cbBalcony = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbFloor = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbAdress = new System.Windows.Forms.TextBox();
            this.tbElconsump = new System.Windows.Forms.TextBox();
            this.tbNumroom = new System.Windows.Forms.TextBox();
            this.tbArea = new System.Windows.Forms.TextBox();
            this.tbNumber = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnShow = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(437, 289);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(184, 44);
            this.button1.TabIndex = 39;
            this.button1.Text = "Show list (foreach)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnShowFor
            // 
            this.btnShowFor.Location = new System.Drawing.Point(436, 227);
            this.btnShowFor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnShowFor.Name = "btnShowFor";
            this.btnShowFor.Size = new System.Drawing.Size(185, 38);
            this.btnShowFor.TabIndex = 38;
            this.btnShowFor.Text = "Show list (for)";
            this.btnShowFor.UseVisualStyleBackColor = true;
            this.btnShowFor.Click += new System.EventHandler(this.btnShowFor_Click);
            // 
            // btnCreateList
            // 
            this.btnCreateList.Location = new System.Drawing.Point(436, 161);
            this.btnCreateList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCreateList.Name = "btnCreateList";
            this.btnCreateList.Size = new System.Drawing.Size(185, 39);
            this.btnCreateList.TabIndex = 37;
            this.btnCreateList.Text = "Create flat list";
            this.btnCreateList.UseVisualStyleBackColor = true;
            this.btnCreateList.Click += new System.EventHandler(this.btnCreateList_Click);
            // 
            // cbBalcony
            // 
            this.cbBalcony.AutoSize = true;
            this.cbBalcony.Location = new System.Drawing.Point(436, 117);
            this.cbBalcony.Name = "cbBalcony";
            this.cbBalcony.Size = new System.Drawing.Size(53, 20);
            this.cbBalcony.TabIndex = 36;
            this.cbBalcony.Text = "Yes";
            this.cbBalcony.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(433, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 16);
            this.label7.TabIndex = 35;
            this.label7.Text = "Enter floor";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(433, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 16);
            this.label6.TabIndex = 34;
            this.label6.Text = "Has balcony?";
            // 
            // tbFloor
            // 
            this.tbFloor.Location = new System.Drawing.Point(436, 46);
            this.tbFloor.Name = "tbFloor";
            this.tbFloor.Size = new System.Drawing.Size(100, 22);
            this.tbFloor.TabIndex = 33;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 289);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 16);
            this.label5.TabIndex = 32;
            this.label5.Text = "Enter adress flat";
            // 
            // tbAdress
            // 
            this.tbAdress.Location = new System.Drawing.Point(53, 312);
            this.tbAdress.Margin = new System.Windows.Forms.Padding(4);
            this.tbAdress.Name = "tbAdress";
            this.tbAdress.Size = new System.Drawing.Size(132, 22);
            this.tbAdress.TabIndex = 31;
            // 
            // tbElconsump
            // 
            this.tbElconsump.Location = new System.Drawing.Point(53, 251);
            this.tbElconsump.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbElconsump.Name = "tbElconsump";
            this.tbElconsump.Size = new System.Drawing.Size(283, 22);
            this.tbElconsump.TabIndex = 30;
            // 
            // tbNumroom
            // 
            this.tbNumroom.Location = new System.Drawing.Point(56, 182);
            this.tbNumroom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbNumroom.Name = "tbNumroom";
            this.tbNumroom.Size = new System.Drawing.Size(280, 22);
            this.tbNumroom.TabIndex = 29;
            // 
            // tbArea
            // 
            this.tbArea.Location = new System.Drawing.Point(53, 115);
            this.tbArea.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbArea.Name = "tbArea";
            this.tbArea.Size = new System.Drawing.Size(283, 22);
            this.tbArea.TabIndex = 28;
            // 
            // tbNumber
            // 
            this.tbNumber.Location = new System.Drawing.Point(53, 47);
            this.tbNumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbNumber.Name = "tbNumber";
            this.tbNumber.Size = new System.Drawing.Size(283, 22);
            this.tbNumber.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 230);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(245, 16);
            this.label4.TabIndex = 26;
            this.label4.Text = "Enter electricity consumption per mounth";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "Enter number of rooms flat";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 16);
            this.label2.TabIndex = 24;
            this.label2.Text = "Enter area flat";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 16);
            this.label1.TabIndex = 23;
            this.label1.Text = "Enter number flat";
            // 
            // btnShow
            // 
            this.btnShow.Location = new System.Drawing.Point(436, 360);
            this.btnShow.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(107, 39);
            this.btnShow.TabIndex = 22;
            this.btnShow.Text = "Show";
            this.btnShow.UseVisualStyleBackColor = true;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(53, 360);
            this.btnSave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(103, 39);
            this.btnSave.TabIndex = 21;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnShowFor);
            this.Controls.Add(this.btnCreateList);
            this.Controls.Add(this.cbBalcony);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbFloor);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbAdress);
            this.Controls.Add(this.tbElconsump);
            this.Controls.Add(this.tbNumroom);
            this.Controls.Add(this.tbArea);
            this.Controls.Add(this.tbNumber);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnShow);
            this.Controls.Add(this.btnSave);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnShowFor;
        private System.Windows.Forms.Button btnCreateList;
        private System.Windows.Forms.CheckBox cbBalcony;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbFloor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbAdress;
        private System.Windows.Forms.TextBox tbElconsump;
        private System.Windows.Forms.TextBox tbNumroom;
        private System.Windows.Forms.TextBox tbArea;
        private System.Windows.Forms.TextBox tbNumber;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.Button btnSave;
    }
}

